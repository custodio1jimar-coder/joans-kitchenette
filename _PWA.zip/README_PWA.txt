JOAN'S KITCHENETTE PWA
Use this app from an HTTPS website.
iPhone: Safari > Share > Add to Home Screen.
Android: Chrome > menu > Add to Home screen / Install.
Windows: Edge/Chrome > Install app.
Camera access requires HTTPS or localhost.
This does not create an App Store IPA; it creates an installable web app.
