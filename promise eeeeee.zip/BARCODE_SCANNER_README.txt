JOAN'S KITCHENETTE - BARCODE SCANNER UPDATE

Added:
- 📷 SCAN ITEM BARCODE button on Grocery/category product screens
- Native Android camera scanner for EAN-13 / UPC-A barcodes
- Product barcode field in Add/Edit Item
- Scanned barcode finds the matching product and adds it to the cart
- Existing login, logo, categories, POS, receipt printing and settings are preserved

Important:
1. Existing products may have no barcode yet.
2. Owner can go to Inventory -> EDIT and enter the actual barcode printed on each product.
3. Scanner requires Camera permission.
4. The scanner is intended for Android APK. The web/desktop version keeps the barcode field, while browser fallback allows manual barcode entry.


CAMERA FIX (v1.1): Preview is forced to portrait orientation, uses a 4:3 sensor preview, disables digital zoom (zoom=0), and prefers continuous autofocus to reduce the cropped/zoomed appearance on phones.
