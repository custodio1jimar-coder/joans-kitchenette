package com.joanskitchenette.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("deprecation")
public class BarcodeScannerActivity extends Activity implements SurfaceHolder.Callback, Camera.PreviewCallback {
    public static final String EXTRA_BARCODE = "barcode";
    private static final int CAMERA_REQUEST = 3001;
    private AspectRatioSurfaceView surface;
    private Camera camera;
    private boolean scanning = true;
    private long lastDecode = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF111111);

        TextView title = new TextView(this);
        title.setText("SCAN ITEM BARCODE");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(20);
        title.setGravity(17);
        title.setPadding(10,20,10,20);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        surface = new AspectRatioSurfaceView(this);
        // Keep the camera preview at the portrait 3:4 aspect ratio.
        // This prevents the 16:9 preview from being stretched/cropped and looking zoomed.
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, 0, 1);
        root.addView(surface, previewLp);

        TextView hint = new TextView(this);
        hint.setText("I-center ang barcode sa camera. EAN-13 / UPC-A supported.");
        hint.setTextColor(0xFFFFFFFF);
        hint.setGravity(17);
        hint.setPadding(10,12,10,12);
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        Button cancel = new Button(this);
        cancel.setText("CANCEL");
        cancel.setOnClickListener(v -> finish());
        root.addView(cancel, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        surface.getHolder().addCallback(this);
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
        }
    }

    @Override public void onRequestPermissionsResult(int req, String[] p, int[] g) {
        super.onRequestPermissionsResult(req,p,g);
        if (req == CAMERA_REQUEST && (g.length == 0 || g[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "Camera permission is required to scan.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override public void surfaceCreated(SurfaceHolder h) {
        try {
            camera = Camera.open(); // Camera 0 = rear camera on normal Android devices.
            camera.setPreviewDisplay(h);

            // The Activity is portrait. Explicitly rotate the camera preview so
            // the preview uses the correct field of view instead of appearing
            // cropped/zoomed.
            camera.setDisplayOrientation(90);

            Camera.Parameters params = camera.getParameters();
            params.setPreviewFormat(ImageFormat.NV21);

            // Prefer a 4:3 sensor preview. The old 1280x720 (16:9) selection
            // was being displayed in a portrait surface and could look heavily
            // cropped/zoomed on some phones.
            List<Camera.Size> sizes = params.getSupportedPreviewSizes();
            Camera.Size best = null;
            double bestScore = Double.MAX_VALUE;
            for (Camera.Size candidate : sizes) {
                double ratio = candidate.width / (double) candidate.height;
                double ratioError = Math.abs(ratio - (4.0 / 3.0));
                double sizeError = Math.abs(candidate.width - 1280) / 1280.0
                        + Math.abs(candidate.height - 960) / 960.0;
                double score = ratioError * 10.0 + sizeError;
                if (best == null || score < bestScore) {
                    best = candidate;
                    bestScore = score;
                }
            }
            if (best != null) params.setPreviewSize(best.width, best.height);

            // Never start with digital zoom. Prefer continuous autofocus when
            // the device supports it.
            if (params.isZoomSupported()) params.setZoom(0);
            List<String> focusModes = params.getSupportedFocusModes();
            if (focusModes != null) {
                if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                } else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                }
            }

            camera.setParameters(params);
            camera.setPreviewCallback(this);
            camera.startPreview();
        } catch (Exception e) {
            Toast.makeText(this, "Camera error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int he) {
        if (camera == null) return;
        try { camera.stopPreview(); camera.setPreviewDisplay(h); camera.startPreview(); } catch(Exception ignored) {}
    }

    @Override public void surfaceDestroyed(SurfaceHolder h) {
        releaseCamera();
    }

    private void releaseCamera() {
        if (camera != null) {
            try { camera.setPreviewCallback(null); camera.stopPreview(); } catch(Exception ignored) {}
            try { camera.release(); } catch(Exception ignored) {}
            camera=null;
        }
    }

    @Override public void onPreviewFrame(byte[] data, Camera c) {
        if (!scanning || data == null || c == null) return;
        long now=System.currentTimeMillis();
        if (now-lastDecode < 180) return;
        lastDecode=now;
        Camera.Size s=c.getParameters().getPreviewSize();
        int[] rows = {s.height/2, s.height/2-30, s.height/2+30, s.height/2-60, s.height/2+60};
        for (int y: rows) {
            if (y<0 || y>=s.height) continue;
            String code=decodeEan13(data,s.width,s.height,y,false);
            if(code==null) code=decodeEan13(data,s.width,s.height,y,true);
            if(code!=null) {
                scanning=false;
                final String result=code;
                runOnUiThread(() -> {
                    Intent out=new Intent();
                    out.putExtra(EXTRA_BARCODE,result);
                    setResult(RESULT_OK,out);
                    finish();
                });
                return;
            }
        }
    }

    private String decodeEan13(byte[] data,int width,int height,int y,boolean reverse) {
        // Scan one horizontal grayscale line and find EAN/UPC start guard.
        int start=reverse?width-1:0, end=reverse?-1:width, step=reverse?-1:1;
        ArrayList<Integer> runs=new ArrayList<>();
        ArrayList<Integer> vals=new ArrayList<>();
        int prev=-1,count=0;
        for(int x=start;x!=end;x+=step){
            int yy=y*width+x;
            int v=(data[yy]&0xff);
            // NV21 Y plane: threshold dynamically around 128.
            int bit=v<128?1:0;
            if(bit==prev) count++;
            else {
                if(count>0){runs.add(count);vals.add(prev);}
                prev=bit;count=1;
            }
        }
        if(count>0){runs.add(count);vals.add(prev);}
        // Try each black run as the first start-guard bar.
        for(int i=0;i+59<runs.size();i++){
            if(vals.get(i)!=1) continue;
            int a=runs.get(i), b=runs.get(i+1), d=runs.get(i+2);
            int unit=(a+b+d)/3;
            if(unit<2) continue;
            if(!near(a,unit,.65)||!near(b,unit,.65)||!near(d,unit,.65)) continue;
            String decoded=decodeFromRuns(runs,vals,i,unit);
            if(decoded!=null) return decoded;
        }
        return null;
    }

    private String decodeFromRuns(ArrayList<Integer> runs,ArrayList<Integer> vals,int i,int unit){
        // EAN-13: start guard + 6 left digits + center + 6 right digits + end guard.
        if(i+3+24+5+24+3 >= runs.size()) return null;
        int pos=i;
        // start 101
        pos+=3;
        StringBuilder left=new StringBuilder();
        StringBuilder parity=new StringBuilder();
        for(int d=0;d<6;d++){
            if(pos+3>=runs.size()) return null;
            int[] q=new int[4];
            for(int k=0;k<4;k++) q[k]=Math.max(1,Math.round(runs.get(pos+k)/(float)unit));
            int digit=-1; char p='?';
            for(int n=0;n<10;n++){
                int[] l=LEFT[n];
                if(eq4(q,l)){digit=n;p='L';break;}
                int[] g=GLEFT[n];
                if(eq4(q,g)){digit=n;p='G';break;}
            }
            if(digit<0) return null;
            left.append((char)('0'+digit)); parity.append(p); pos+=4;
        }
        // center 01010 = five runs
        if(pos+4>=runs.size()) return null;
        int centerSum=runs.get(pos)+runs.get(pos+1)+runs.get(pos+2)+runs.get(pos+3)+runs.get(pos+4);
        if(!near(centerSum,7*unit,.45)) return null;
        pos+=5;
        StringBuilder right=new StringBuilder();
        for(int d=0;d<6;d++){
            if(pos+3>=runs.size()) return null;
            int[] q=new int[4];
            for(int k=0;k<4;k++) q[k]=Math.max(1,Math.round(runs.get(pos+k)/(float)unit));
            int digit=-1;
            for(int n=0;n<10;n++) if(eq4(q,RIGHT[n])){digit=n;break;}
            if(digit<0) return null;
            right.append((char)('0'+digit)); pos+=4;
        }
        if(pos+2>=runs.size()) return null;
        String first=parityToFirst(parity.toString());
        if(first==null) return null;
        String code=first+left+right;
        if(code.length()!=13 || !checkDigit(code)) return null;
        return code;
    }

    private boolean eq4(int[] q,int[] p){
        int err=0;
        for(int i=0;i<4;i++) err+=Math.abs(q[i]-p[i]);
        return err<=1;
    }
    private boolean near(int a,int b,double tol){return Math.abs(a-b)<=b*tol;}

    private String parityToFirst(String p){
        String[] map={"LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"};
        for(int i=0;i<map.length;i++) if(map[i].equals(p)) return String.valueOf(i);
        return null;
    }
    private boolean checkDigit(String s){
        int sum=0;
        for(int i=0;i<12;i++){int n=s.charAt(i)-'0';sum += (i%2==0)?n:n*3;}
        int cd=(10-(sum%10))%10;
        return cd==(s.charAt(12)-'0');
    }

    // EAN-13 run-length patterns expressed in modules (4 runs per digit).
    private static final int[][] LEFT={
        {3,2,1,1},{2,2,2,1},{2,1,2,2},{1,4,1,1},{1,1,3,2},
        {1,2,3,1},{1,1,1,4},{1,3,1,2},{1,2,1,3},{3,1,1,2}
    };
    private static final int[][] GLEFT={
        {1,1,2,3},{1,2,2,2},{2,2,1,2},{1,1,4,1},{2,3,1,1},
        {1,3,2,1},{4,1,1,1},{2,1,3,1},{3,1,2,1},{2,1,1,3}
    };
    private static final int[][] RIGHT={
        {3,2,1,1},{2,2,2,1},{2,1,2,2},{1,4,1,1},{1,1,3,2},
        {1,2,3,1},{1,1,1,4},{1,3,1,2},{1,2,1,3},{3,1,1,2}
    };

    /**
     * Camera preview with a fixed portrait 3:4 aspect ratio.
     * A 4:3 camera buffer shown directly inside a 9:16 view can be
     * cropped by the device and look like a zoomed camera. Keeping the
     * preview ratio consistent avoids that effect.
     */
    private static class AspectRatioSurfaceView extends SurfaceView {
        private static final float RATIO = 3f / 4f; // portrait width / height

        public AspectRatioSurfaceView(android.content.Context context) {
            super(context);
            setBackgroundColor(0xFF000000);
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int height = MeasureSpec.getSize(heightMeasureSpec);
            int widthMode = MeasureSpec.getMode(widthMeasureSpec);
            int heightMode = MeasureSpec.getMode(heightMeasureSpec);

            if (widthMode == MeasureSpec.EXACTLY && heightMode == MeasureSpec.EXACTLY) {
                int desiredHeight = Math.round(width / RATIO);
                if (desiredHeight <= height) {
                    setMeasuredDimension(width, desiredHeight);
                } else {
                    int desiredWidth = Math.round(height * RATIO);
                    setMeasuredDimension(desiredWidth, height);
                }
                return;
            }

            if (width > 0) {
                int desiredHeight = Math.round(width / RATIO);
                if (heightMode == MeasureSpec.AT_MOST) desiredHeight = Math.min(desiredHeight, height);
                setMeasuredDimension(width, desiredHeight);
            } else {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            }
        }
    }

}
