package com.joanskitchenette.app;

import android.app.Activity;
import android.content.Intent;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.net.Uri;
import android.widget.Toast;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int BARCODE_SCAN_REQUEST = 2001;
    private WebView printWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppBridge {
        @JavascriptInterface
        public void printReceipt(String html) {
            runOnUiThread(() -> {
                try {
                    printWebView = new WebView(MainActivity.this);
                    WebSettings ps = printWebView.getSettings();
                    ps.setJavaScriptEnabled(false);
                    printWebView.setWebViewClient(new WebViewClient() {
                        @Override public void onPageFinished(WebView view, String url) {
                            PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                            if (printManager == null) {
                                Toast.makeText(MainActivity.this, "Printing service is not available.", Toast.LENGTH_LONG).show();
                                return;
                            }
                            PrintAttributes attributes = new PrintAttributes.Builder()
                                    .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();
                            printManager.print("Joan's Kitchenette Receipt", view.createPrintDocumentAdapter("Joan's Kitchenette Receipt"), attributes);
                        }
                    });
                    String printHtml = "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>body{font-family:Arial,sans-serif;margin:0;padding:16px;color:#222}.receipt-print{max-width:360px;margin:auto;font-size:14px;line-height:1.45}.center{text-align:center}.line{border-top:1px dashed #777;margin:10px 0}.row{display:flex;justify-content:space-between;gap:10px}h2{margin:0 0 4px;font-size:20px}small{color:#666}@media print{body{padding:0}.receipt-print{max-width:none}}</style></head><body>" + html + "</body></html>";
                    printWebView.loadDataWithBaseURL(null, printHtml, "text/html", "UTF-8", null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to start printing: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void startBarcodeScan() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(MainActivity.this, BarcodeScannerActivity.class);
                    startActivityForResult(intent, BARCODE_SCAN_REQUEST);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Unable to open barcode camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == BARCODE_SCAN_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                String code = data.getStringExtra(BarcodeScannerActivity.EXTRA_BARCODE);
                if (code != null && !code.trim().isEmpty()) {
                    String safe = org.json.JSONObject.quote(code.trim());
                    webView.evaluateJavascript("window.onBarcodeScanned && window.onBarcodeScanned(" + safe + ")", null);
                }
            }
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) results = new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
