-keepclassmembers class com.joanskitchenette.app.MainActivity$AppBridge {
    <methods>;
}
-keepclass class com.joanskitchenette.app.MainActivity$AppBridge { *; }
-keepclass class com.joanskitchenette.app.BarcodeScannerActivity { *; }
