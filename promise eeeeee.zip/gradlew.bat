@echo off
setlocal
set APP_HOME=%~dp0
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo ERROR: Gradle 8.9 is not installed. Open this project in Android Studio/AIDE with Gradle support.
exit /b 1
