const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
function createWindow(){
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 650,
    backgroundColor: '#f4efe9',
    webPreferences: { contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname,'app','index.html'));
  Menu.setApplicationMenu(null);
}
app.whenReady().then(()=>{createWindow(); app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0) createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin') app.quit();});
