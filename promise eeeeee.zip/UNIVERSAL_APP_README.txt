JOAN'S KITCHENETTE - PHONE + COMPUTER

This package now supports one web interface in three ways:

1) ANDROID APK
   Open the existing project in Android Studio:
   Build > Build APK(s).
   The Android app keeps the existing Login, Logo, Dashboard, Categories,
   Inventory, Sales, GCash QR setup, Settings and PRINT RECEIPT.

2) PHONE / TABLET AS INSTALLABLE WEB APP (PWA)
   Serve the web_app folder from a web server (HTTPS recommended), open it in
   Chrome/Edge on the phone, then choose Install app / Add to Home screen.
   Data is stored locally in the browser (localStorage), as in the current app.

3) WINDOWS / MAC / LINUX DESKTOP APP
   Open desktop_app in a terminal:
     npm install
     npm start
   To build installers:
     npm run dist
   electron-builder will create Windows installers/portable builds, plus
   macOS/Linux targets when run on supported environments.

PRINT RECEIPT
   On Android it uses the Android system print dialog.
   In desktop/PWA browsers it opens the browser print dialog.
   A compatible printer/print service must be installed and selected.

IMPORTANT DATA NOTE
   The current app stores products, orders, settings and GCash QR locally on
   each device/browser. Phone and computer do NOT automatically share data.
   A future cloud/database sync can be added if you want one shared inventory.
